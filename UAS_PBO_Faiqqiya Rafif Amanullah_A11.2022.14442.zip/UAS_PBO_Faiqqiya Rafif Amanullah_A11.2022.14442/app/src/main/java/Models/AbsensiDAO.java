/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author acer
 */
import Entities.Absensi;
import java.util.List;

public interface AbsensiDAO {

    void insertAbsensi(Absensi absensi);

    Absensi selectAbsensiById(String id_absensi);

    List<Absensi> selectALLAbsensi();

    void updateAbsensi(Absensi absensi);

    void deleteAbsensi(String id_absensi);

}
