package Models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Entities.Kehadiran;
import helpers.KoneksiDB;

public class KehadiranSQLite implements KehadiranDAO {

    @Override
    public void deleteKehadiran(String id_kehadiran) {
        String sql = "DELETE FROM kehadiran WHERE id_kehadiran = ?";

        try (Connection conn = KoneksiDB.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, id_kehadiran);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    @Override
    public void insertKehadiran(Kehadiran kehadiran) {
        String sql = "insert into kehadiran(id_kehadiran, id_pegawai, tanggal, waktu_masuk, waktu_keluar, durasi_kerja) values (?, ?, ?, ?, ?, ?)";

        try (Connection conn = KoneksiDB.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, kehadiran.id_kehadiran);
            pstmt.setString(2, kehadiran.id_pegawai);
            pstmt.setString(3, kehadiran.tanggal);
            pstmt.setString(4, kehadiran.waktu_masuk);
            pstmt.setString(5, kehadiran.waktu_keluar);
            pstmt.setString(6, kehadiran.durasi_kerja);

            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Kehadiran> selectAllKehadiran() {
        String sql = "SELECT * FROM kehadiran";
        List<Kehadiran> dataKehadiran = new ArrayList<>();

        try (Connection conn = KoneksiDB.connect();
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);) {

            while (rs.next()) {
                Kehadiran kehadiran = new Kehadiran(
                        rs.getString("id_kehadiran"),
                        rs.getString("id_pegawai"),
                        rs.getString("tanggal"),
                        rs.getString("waktu_masuk"),
                        rs.getString("waktu_keluar"),
                        rs.getString("durasi_kerja")

                );
                dataKehadiran.add(kehadiran);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return dataKehadiran;
    }

    @Override
    public Kehadiran selectKehadiranById(String id_kehadiran) {
        String sql = "SELECT * FROM kehadiran WHERE id_kehadiran = ?";
        Kehadiran kehadiran = null;

        try (Connection conn = KoneksiDB.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);) {

            pstmt.setString(1, id_kehadiran);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                kehadiran = new Kehadiran(
                        rs.getString("id_kehadiran"),
                        rs.getString("id_pegawai"),
                        rs.getString("tanggal"),
                        rs.getString("waktu_masuk"),
                        rs.getString("waktu_keluar"),
                        rs.getString("durasi_kerja")

                );
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return kehadiran;
    }

    @Override
    public void updateKehadiran(Kehadiran kehadiran) {
        String sql = "UPDATE  kehadiran SET id_pegawai = ?, tanggal = ?, waktu_masuk = ?, waktu_keluar = ?,  durasi_kerja = ? WHERE id_kehadiran = ?";

        try (Connection conn = KoneksiDB.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, kehadiran.id_pegawai);
            pstmt.setString(2, kehadiran.tanggal);
            pstmt.setString(3, kehadiran.waktu_masuk);
            pstmt.setString(4, kehadiran.waktu_keluar);
            pstmt.setString(5, kehadiran.durasi_kerja);
            pstmt.setString(6, kehadiran.id_kehadiran);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

}
