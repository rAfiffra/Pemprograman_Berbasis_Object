package Models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Entities.Absensi;
import helpers.KoneksiDB;

public class AbsensiSQLite implements AbsensiDAO {

//  private Connection conn;
//
//  public AbsensiSQLite(Connection conn) {
//
//    this.conn = conn;
//  }

  @Override
  public void deleteAbsensi(String id_absensi) {
    String sql = "DELETE FROM absensi WHERE id_absensi = ?";

    try (Connection conn = KoneksiDB.connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

      pstmt.setString(1, id_absensi);
      pstmt.executeUpdate();

    } catch (SQLException e) {
      System.out.println(e.getMessage());
    }

  }

  @Override
  public void insertAbsensi(Absensi absensi) {
    String sql = "insert into absensi(id_absensi, id_pegawai, tanggal, tipe_absensi, alasan) values (?, ?, ?, ?, ?)";

    try (Connection conn = KoneksiDB.connect();
         PreparedStatement pstmt = conn.prepareStatement(sql)) {
      pstmt.setString(1, absensi.id_absensi);
      pstmt.setString(2, absensi.id_pegawai);
      pstmt.setString(3, absensi.tanggal);
      pstmt.setString(4, absensi.tipe_absensi);
      pstmt.setString(5, absensi.alasan);

      pstmt.executeUpdate();

    } catch (SQLException e) {
      e.printStackTrace();
    }

  }

  @Override
  public List<Absensi> selectALLAbsensi() {
    String sql = "SELECT * FROM absensi";
    List<Absensi> dataAbsensi = new ArrayList<>();

    try (Connection conn = KoneksiDB.connect();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);) {

      while (rs.next()) {
        Absensi absensi = new Absensi(
            rs.getString("id_absensi"),
            rs.getString("id_pegawai"),
            rs.getString("tanggal"),
            rs.getString("tipe_absensi"),
            rs.getString("alasan"));
        dataAbsensi.add(absensi);
      }

    } catch (SQLException e) {
      System.out.println(e.getMessage());
    }

    return dataAbsensi;
  }

  @Override
  public Absensi selectAbsensiById(String id_absensi) {
    String sql = "SELECT * FROM absensi WHERE id_absensi = ?";
    Absensi absensi = null;

    try (Connection conn = KoneksiDB.connect();
        PreparedStatement pstmt = conn.prepareStatement(sql);) {

      pstmt.setString(1, id_absensi);
      ResultSet rs = pstmt.executeQuery();

      if (rs.next()) {
        absensi = new Absensi(
            rs.getString("id_absensi"),
            rs.getString("id_pegawai"),
            rs.getString("tanggal"),
            rs.getString("tipe_absensi"),
            rs.getString("alasan"));
      }

    } catch (SQLException e) {
      System.out.println(e.getMessage());
    }
    return absensi;
  }

  @Override
  public void updateAbsensi(Absensi absensi) {
    String sql = "UPDATE  absensi SET id_pegawai = ?, tanggal = ?, tipe_absensi = ?, alasan = ? WHERE id_absensi = ?";

    try (Connection conn = KoneksiDB.connect();
        PreparedStatement pstmt = conn.prepareStatement(sql)) {

      pstmt.setString(1, absensi.id_pegawai);
      pstmt.setString(2, absensi.tanggal);
      pstmt.setString(3, absensi.tipe_absensi);
      pstmt.setString(4, absensi.alasan);
      pstmt.setString(5, absensi.id_absensi);
      pstmt.executeUpdate();

    } catch (SQLException e) {
      System.out.println(e.getMessage());
    }

  }

}
