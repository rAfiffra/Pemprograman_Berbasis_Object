package Models;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Entities.Pegawai;
import helpers.KoneksiDB;

public class PegawaiSQLite implements PegawaiDAO {
 

    @Override
    public void insertPegawai(Pegawai pegawai) {
        String sql = "insert into pegawai(id_Pegawai, nama, alamat, tanggal_masuk) values (?, ?, ?, ?)";

        try (Connection conn = KoneksiDB.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, pegawai.id_Pegawai);
            pstmt.setString(2, pegawai.nama);
            pstmt.setString(3, pegawai.alamat);
            pstmt.setString(4, pegawai.tanggal_masuk);

            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Pegawai selectPegawaiById(String id_pegawai) {
        String sql = "SELECT * FROM pegawai WHERE id_pegawai = ?";
        Pegawai pegawai = null;

        try (Connection conn = KoneksiDB.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql);) {

            pstmt.setString(1, id_pegawai);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                pegawai = new Pegawai(
                        rs.getString("id_Pegawai"),
                        rs.getString("nama"),
                        rs.getString("alamat"),
                        rs.getString("tanggal_masuk"));
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return pegawai;
    }

    @Override
    public List<Pegawai> selectALLPegawai() {
        String sql = "SELECT * FROM pegawai";
        List<Pegawai> dataPegawai = new ArrayList<>();

        try (Connection conn = KoneksiDB.connect();
            Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql);) {

            while (rs.next()) {
                Pegawai pegawai = new Pegawai(
                        rs.getString("id_Pegawai"),
                        rs.getString("nama"),
                        rs.getString("alamat"),
                        rs.getString("tanggal_masuk"));
                dataPegawai.add(pegawai);
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return dataPegawai;
    }

    @Override
    public void updatePegawai(Pegawai pegawai) {
        String sql = "UPDATE  pegawai SET nama = ?, alamat = ?, tanggal_masuk = ? WHERE id_Pegawai = ?";

        try (Connection conn = KoneksiDB.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, pegawai.nama);
            pstmt.setString(2, pegawai.alamat);
            pstmt.setString(3, pegawai.tanggal_masuk);
            pstmt.setString(4, pegawai.id_Pegawai);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void deletePegawai(String id_pegawai) {
        String sql = "DELETE FROM pegawai WHERE id_pegawai = ?";

        try (Connection conn = KoneksiDB.connect();
            PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, id_pegawai);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

}
