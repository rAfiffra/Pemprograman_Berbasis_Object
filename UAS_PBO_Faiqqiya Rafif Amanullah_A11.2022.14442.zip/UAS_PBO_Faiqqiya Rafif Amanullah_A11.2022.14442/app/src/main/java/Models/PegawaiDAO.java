/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Models;

/**
 *
 * @author acer
 */
import Entities.Pegawai;
import java.util.List;

public interface PegawaiDAO {
    void insertPegawai(Pegawai pegawai);

    Pegawai selectPegawaiById(String id_pegawai);

    List<Pegawai> selectALLPegawai();

    void updatePegawai(Pegawai pegawai);

    void deletePegawai(String id_pegawai);
}
