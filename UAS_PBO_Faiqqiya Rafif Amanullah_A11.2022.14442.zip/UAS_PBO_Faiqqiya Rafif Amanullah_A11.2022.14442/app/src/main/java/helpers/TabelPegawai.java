/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helpers;

import Entities.Pegawai;
import java.util.List;

import javax.swing.table.AbstractTableModel;

/**
 *
 * @author acer
 */
public class TabelPegawai extends AbstractTableModel {

  List<Pegawai> dataPegawai;
  String[] header = { "Id Pegawai", "Nama", "Alamat", "Tanggal MAsuk" };

  public TabelPegawai(List<Pegawai> dataPegawai) {
    this.dataPegawai = dataPegawai;
  }

  @Override
  public String getColumnName(int column) {
    return header[column];
  }

  @Override
  public int getRowCount() {
    return dataPegawai.size();
  }

  @Override
  public int getColumnCount() {
    return header.length;
  }

  @Override
  public Object getValueAt(int rowIndex, int columnIndex) {
    if (columnIndex == 0) {
      return dataPegawai.get(rowIndex).id_Pegawai;
    } else if (columnIndex == 1) {
      return dataPegawai.get(rowIndex).nama;
    } else if (columnIndex == 2) {
      return dataPegawai.get(rowIndex).alamat;
    } else {
      return dataPegawai.get(rowIndex).tanggal_masuk;
    }
  }
}
