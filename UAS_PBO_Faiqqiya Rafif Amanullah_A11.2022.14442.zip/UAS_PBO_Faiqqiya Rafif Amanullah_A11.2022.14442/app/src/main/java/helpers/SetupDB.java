/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helpers;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class SetupDB {

    public static void migrate() {
        String[] sql = { """
                CREATE TABLE IF NOT EXISTS Pegawai(
                    id_pegawai VARCHAR(25)PRIMARY KEY,
                    nama VARCHAR(50),
                    alamat VARCHAR(30),
                    tanggal_masuk VARCHAR(30));""",

                """
                        CREATE TABLE IF NOT EXISTS Kehadiran (
                            id_kehadiran VARCHAR(25)PRIMARY KEY,
                            id_pegawai VARCHAR(25),
                            tanggal VARCHAR(15),
                            waktu_masuk VARCHAR(25),
                            waktu_keluar VARCHAR(25),
                            durasi_kerja VARCHAR(25),
                            FOREIGN KEY (id_kehadiran) REFERENCES pegawai(id_pegawai)
                        );""",

                """
                        CREATE TABLE IF NOT EXISTS absensi (
                            id_absensi VARCHAR(25) PRIMARY KEY,
                            id_pegawai VARCHAR(25),
                            tanggal VARCHAR(15),
                            tipe_absensi varchar(10),
                            alasan VARCHAR(15),
                            FOREIGN KEY (id_absensi) REFERENCES pegawai(id_pegawai)
                        );""",
        };

        try (Connection conn = KoneksiDB.connect();
                Statement stmt = conn.createStatement()) {

            for (String query : sql)
                stmt.executeUpdate(query);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
