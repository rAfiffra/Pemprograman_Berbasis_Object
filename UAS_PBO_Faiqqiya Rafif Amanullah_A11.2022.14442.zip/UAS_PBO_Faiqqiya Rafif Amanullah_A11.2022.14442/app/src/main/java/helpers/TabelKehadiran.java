/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helpers;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import Entities.Kehadiran;

/**
 *
 * @author acer
 */

public class TabelKehadiran extends AbstractTableModel {

  List<Kehadiran> dataKehadiran;
  String[] header = { "Id Kehadiran", "Id Pegawai", "Tanggal", "Jam Masuk", "Jam Keluar", "Durasi Kerja" };

  public TabelKehadiran(List<Kehadiran> dataKehadiran) {
    this.dataKehadiran = dataKehadiran;
  }

  @Override
  public String getColumnName(int column) {
    return header[column];
  }

  @Override
  public int getRowCount() {
    return dataKehadiran.size();
  }

  @Override
  public int getColumnCount() {
    return header.length;
  }

  @Override
  public Object getValueAt(int rowIndex, int columnIndex) {
    if (columnIndex == 0) {
      return dataKehadiran.get(rowIndex).id_kehadiran;
    } else if (columnIndex == 1) {
      return dataKehadiran.get(rowIndex).id_pegawai;
    } else if (columnIndex == 2) {
      return dataKehadiran.get(rowIndex).tanggal;
    } else if (columnIndex == 3) {
      return dataKehadiran.get(rowIndex).waktu_masuk;
    } else if (columnIndex == 4) {
      return dataKehadiran.get(rowIndex).waktu_keluar;
    } else {
      return dataKehadiran.get(rowIndex).durasi_kerja;
    }
  }
}
