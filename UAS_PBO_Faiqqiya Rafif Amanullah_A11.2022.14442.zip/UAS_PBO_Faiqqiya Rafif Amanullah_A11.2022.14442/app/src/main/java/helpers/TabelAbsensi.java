/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helpers;

import Entities.Absensi;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author acer
 */
public class TabelAbsensi extends AbstractTableModel {

  List<Absensi> dataAbsensi;
  String[] header = { "Id Absensi", "Id Pegawai", "Tanggal", "Tipe Absen", "Alasan" };

  public TabelAbsensi(List<Absensi> dataAbsensi) {
    this.dataAbsensi = dataAbsensi;
  }

  @Override
  public String getColumnName(int column) {
    return header[column];
  }

  @Override
  public int getRowCount() {
    return dataAbsensi.size();
  }

  @Override
  public int getColumnCount() {
    return header.length;
  }

  @Override
  public Object getValueAt(int rowIndex, int columnIndex) {
    if (columnIndex == 0) {
      return dataAbsensi.get(rowIndex).id_absensi;
    } else if (columnIndex == 1) {
      return dataAbsensi.get(rowIndex).id_pegawai;
    } else if (columnIndex == 2) {
      return dataAbsensi.get(rowIndex).tanggal;
    } else if (columnIndex == 3) {
      return dataAbsensi.get(rowIndex).tipe_absensi;
    } else {
      return dataAbsensi.get(rowIndex).alasan;
    }
  }

}
