/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entities;

public class Absensi {
    public String id_absensi;
    public String id_pegawai;
    public String tanggal;
    public String tipe_absensi;
    public String alasan;

    public Absensi(String id_absensi, String id_pegawai, String tanggal, String tipe_absensi, String alasan) {
        this.id_absensi = id_absensi;
        this.id_pegawai = id_pegawai;
        this.tanggal = tanggal;
        this.tipe_absensi = tipe_absensi;
        this.alasan = alasan;
    }

    @Override
    public String toString() {
        return "[" + id_absensi + "] " + id_pegawai + " - (" + tanggal + " | " + tipe_absensi + " | " + alasan + " ";
    }

}
