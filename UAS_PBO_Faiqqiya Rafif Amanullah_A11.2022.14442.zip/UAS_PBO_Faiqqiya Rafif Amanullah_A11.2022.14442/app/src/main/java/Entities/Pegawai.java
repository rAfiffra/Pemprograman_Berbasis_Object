/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entities;

public class Pegawai {
    public String id_Pegawai;
    public String nama;
    public String alamat;
    public String tanggal_masuk;

    public Pegawai(String id_Pegawai, String nama, String alamat, String tanggal_masuk) {
        this.id_Pegawai = id_Pegawai;
        this.nama = nama;
        this.alamat = alamat;
        this.tanggal_masuk = tanggal_masuk;
    }

    @Override
    public String toString() {
        return "[" + id_Pegawai + "] " + nama + " - (" + alamat + " | " + tanggal_masuk + ") ";
    }
    
    public String getIdPegawai() {
        return id_Pegawai;
    }

    public String getNama() {
        return nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getTanggalMasuk() {
        return tanggal_masuk;
    }

}
