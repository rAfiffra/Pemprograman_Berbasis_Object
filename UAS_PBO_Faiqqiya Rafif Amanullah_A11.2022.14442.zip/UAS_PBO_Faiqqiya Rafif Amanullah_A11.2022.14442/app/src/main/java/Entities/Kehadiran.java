/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entities;

public class Kehadiran {
  public String id_kehadiran;
  public String id_pegawai;
  public String tanggal;
  public String waktu_keluar;
  public String waktu_masuk;
  public String durasi_kerja;

  public Kehadiran(String id_kehadiran, String id_pegawai, String tanggal, String waktuMasuk, String waktuKeluar,
      String durasiKerja) {
    this.id_kehadiran = id_kehadiran;
    this.id_pegawai = id_pegawai;
    this.tanggal = tanggal;
    this.waktu_masuk = waktuMasuk;
    this.waktu_keluar = waktuKeluar;
    this.durasi_kerja = durasiKerja;
  }

  @Override
  public String toString() {
    return "[" + id_kehadiran + "] " + id_pegawai + " - (" + tanggal + " | " + waktu_keluar + " | " + waktu_masuk
        + " | "
        + durasi_kerja + ") ";
  }
}
